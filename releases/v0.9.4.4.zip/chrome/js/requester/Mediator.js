var Mediator = Backbone.Model.extend({
    defaults: function() {
        return {
        }
    }
});